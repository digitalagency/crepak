--
-- Database: `db_crepak`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_article`
--

CREATE TABLE `tbl_article` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `article` text NOT NULL,
  `image` text,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_article`
--

INSERT INTO `tbl_article` (`id`, `title`, `slug`, `article`, `image`, `status`, `created_date`) VALUES
(1, 'Binaya Shrestha', 'binaya-shrestha', '                              <p>Hello There,</p>\r\n\r\n<p>Myself Binaya Shrestha a 90’s boy from Bailachhen,Patan,Nepal. Student of Computer Engineering from CITE, did my schooling from A.V.M Higher Secondary School(Celebrating its glorious 50 year).</p>\r\n\r\n<p>Regarding my working career, currently working as a PHP Web Developer. Also have good knowledge about CSS, Photoshop. Coding is always fun.</p>\r\n\r\n<p>Talking about my hobbies</p>\r\n\r\n<p>Watching TV (specially cartoons/anime <img alt="????" src="https://s.w.org/images/core/emoji/72x72/1f600.png" /> ),</p>\r\n\r\n<p>Mobiles/ Gadgets,</p>\r\n\r\n<p>Photography,</p>\r\n\r\n<p>and many more…</p>\r\n                            ', '24029binaya.jpg', '1', '2016-09-05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE `tbl_gallery` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `image` varchar(225) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_gallery`
--

INSERT INTO `tbl_gallery` (`id`, `title`, `slug`, `image`, `status`, `created_date`) VALUES
(1, 'Ghum gham', 'ghum-gham', '91459binaya.jpg', '1', '2016-09-08'),
(2, 'Birthday', 'birthday', '65988nagrikta.jpg', '1', '2016-09-08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery_image`
--

CREATE TABLE `tbl_gallery_image` (
  `id` int(11) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `image` varchar(225) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_gallery_image`
--

INSERT INTO `tbl_gallery_image` (`id`, `gallery_id`, `image`, `status`, `created_date`) VALUES
(16, 1, '68863^356322A5F42F86E588AF8BB309D6A85524F665C1B35FE26E6D^pimgpsh_fullsize_distr.jpg', '1', '2016-09-08'),
(17, 1, '9842012140763_10154083313630139_5903934300415689011_n.jpg', '1', '2016-09-08'),
(20, 1, '29712nagrikta.jpg', '1', '2016-09-08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `article_link` varchar(100) NOT NULL,
  `page_link` varchar(100) NOT NULL,
  `external` enum('1','0') NOT NULL DEFAULT '0',
  `exteral_link` varchar(100) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`id`, `parent_id`, `title`, `slug`, `article_link`, `page_link`, `external`, `exteral_link`, `status`, `created_date`) VALUES
(1, 0, 'About Me', 'about-me', 'binaya-shrestha', '', '0', '', '1', '2016-09-08'),
(3, 0, 'Dilbar mere', 'dilbar-mere', '', '', '1', 'https://www.youtube.com/watch?v=iFwRoxuN_9o', '1', '2016-09-06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `title_cn` varchar(100) NOT NULL,
  `content` longtext NOT NULL,
  `content_cn` longtext NOT NULL,
  `excrept` text NOT NULL,
  `excrept_cn` text NOT NULL,
  `featured_img` varchar(220) NOT NULL,
  `featured_img_cn` varchar(220) DEFAULT NULL,
  `post_type` varchar(100) NOT NULL,
  `post_parent` varchar(100) NOT NULL,
  `post_order` int(11) NOT NULL,
  `post_date` datetime NOT NULL,
  `post_update` datetime NOT NULL,
  `status` int(11) NOT NULL,
  `slug` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `title`, `title_cn`, `content`, `content_cn`, `excrept`, `excrept_cn`, `featured_img`, `featured_img_cn`, `post_type`, `post_parent`, `post_order`, `post_date`, `post_update`, `status`, `slug`) VALUES
(2, 'Main Category', '主要類別', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '<p>Lorem Ipsum只是印刷和排版行業的虛擬文字。 自從15世紀15年代以來，Lorem Ipsum一直是行業標準的虛擬文本，當時一個未知的打印機拿了一個類型的廚房，並加了一個類型的樣本書。 它已經生存了不止五個世紀，而且還跨越了電子排版，基本保持不變。 它在20世紀60年代被普及，並發行了包含Lorem Ipsum段落的Letraset片，最近還有一些桌面出版軟件，如Aldus PageMaker，包括Lorem Ipsum的版本。</p>\r\n', '', '', '27072review_miniondave_1.jpg', '65100img.jpg', 'pages', '', 0, '2017-05-26 13:43:49', '2017-05-29 00:00:00', 1, 'main-category'),
(3, 'Testing For Images update', '測試圖像', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '<p>Lorem Ipsum只是印刷和排版行業的虛擬文字。 自從15世紀15年代以來，Lorem Ipsum一直是行業標準的虛擬文本，當時一個未知的打印機拿了一個類型的廚房，並加了一個類型的樣本書。 它已經生存了不止五個世紀，而且還跨越了電子排版，基本保持不變。 它在20世紀60年代被普及，並發行了包含Lorem Ipsum段落的Letraset片，最近還有一些桌面出版軟件，如Aldus PageMaker，包括Lorem Ipsum的版本。</p>\r\n', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>\r\n', '<p>Lorem Ipsum只是印刷和排版行業的虛擬文字。 自從15世紀15年代以來，Lorem Ipsum一直是行業標準的虛擬文本，</p>\r\n', '87500img.jpg', '996710288762_919423534752419_1066153914971804929_n.jpg', 'pages', '', 0, '2017-05-29 07:16:44', '2017-05-29 00:00:00', 1, 'testing-for-images-update');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$VSPeb9I.CeeAiPn24qWDdOcZVTRz8dc9pCT7WeBQzVRxlRNa0w4Ka', '', 'admin@admin.com', '', 'rFUnWXQ21qXQL1DTH58nou950be96e55dcb6f755', 1495709919, 'jEMPRLReDNO6TXjx0afxtO', 1268889823, 1496033132, 1, 'binaya', 'shresthaaa', 'ADMIN', '0');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_article`
--
ALTER TABLE `tbl_article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tbl_gallery_image`
--
ALTER TABLE `tbl_gallery_image`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_article`
--
ALTER TABLE `tbl_article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_gallery_image`
--
ALTER TABLE `tbl_gallery_image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

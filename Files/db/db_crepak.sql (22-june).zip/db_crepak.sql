--
-- Database: `db_crepak`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_images`
--

CREATE TABLE `tbl_images` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `image` varchar(225) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_images`
--

INSERT INTO `tbl_images` (`id`, `post_id`, `image`, `status`, `created_date`) VALUES
(7, 22, '6634820100714078.jpg', '0', '2017-06-15'),
(8, 22, '46503201143_502217573135428_1051192523_o.jpg', '1', '2017-06-15'),
(9, 20, '11822Bataart1.jpg', '1', '2017-06-15'),
(10, 20, '98203Bataart2.jpg', '1', '2017-06-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `title_cn` varchar(150) NOT NULL,
  `page_link` varchar(225) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `menu_order` int(11) NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`id`, `parent_id`, `title`, `title_cn`, `page_link`, `status`, `menu_order`, `created_date`) VALUES
(1, 0, 'Home', '家', 'index', '1', 1, '2017-06-21'),
(2, 0, 'Product', '产品', '', '1', 2, '2017-06-21'),
(3, 0, 'Application', '应用', 'applications', '1', 3, '2017-06-22'),
(4, 0, 'Contact', '联系', 'contact', '1', 4, '2017-06-21'),
(5, 2, 'Product Category', '产品分类', 'category/category-testing', '1', 1, '2017-06-21'),
(6, 5, 'Product Testing', 'Product Testing Chinese', 'product/product-testing', '1', 1, '2017-06-16'),
(7, 0, 'Main Categry', 'Main Categry Chinese', 'pages/main-category', '1', 5, '2017-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `title_cn` varchar(100) NOT NULL,
  `content` longtext NOT NULL,
  `content_cn` longtext NOT NULL,
  `excrept` text NOT NULL,
  `excrept_cn` text NOT NULL,
  `featured_img` varchar(220) NOT NULL,
  `featured_img_cn` varchar(220) DEFAULT NULL,
  `post_type` varchar(100) NOT NULL,
  `post_parent` int(11) NOT NULL,
  `post_order` int(11) NOT NULL,
  `post_date` datetime NOT NULL,
  `post_update` datetime NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `slug` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `title`, `title_cn`, `content`, `content_cn`, `excrept`, `excrept_cn`, `featured_img`, `featured_img_cn`, `post_type`, `post_parent`, `post_order`, `post_date`, `post_update`, `status`, `slug`) VALUES
(2, 'Main Category', '主要類別', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '<p>Lorem Ipsum只是印刷和排版行業的虛擬文字。 自從15世紀15年代以來，Lorem Ipsum一直是行業標準的虛擬文本，當時一個未知的打印機拿了一個類型的廚房，並加了一個類型的樣本書。 它已經生存了不止五個世紀，而且還跨越了電子排版，基本保持不變。 它在20世紀60年代被普及，並發行了包含Lorem Ipsum段落的Letraset片，最近還有一些桌面出版軟件，如Aldus PageMaker，包括Lorem Ipsum的版本。</p>\r\n', '', '', '27072review_miniondave_1.jpg', '65100img.jpg', 'pages', 0, 0, '2017-05-26 13:43:49', '2017-05-29 00:00:00', '1', 'main-category'),
(3, 'Testing For Images update', '測試圖像', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '<p>Lorem Ipsum只是印刷和排版行業的虛擬文字。 自從15世紀15年代以來，Lorem Ipsum一直是行業標準的虛擬文本，當時一個未知的打印機拿了一個類型的廚房，並加了一個類型的樣本書。 它已經生存了不止五個世紀，而且還跨越了電子排版，基本保持不變。 它在20世紀60年代被普及，並發行了包含Lorem Ipsum段落的Letraset片，最近還有一些桌面出版軟件，如Aldus PageMaker，包括Lorem Ipsum的版本。</p>\r\n', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>\r\n', '<p>Lorem Ipsum只是印刷和排版行業的虛擬文字。 自從15世紀15年代以來，Lorem Ipsum一直是行業標準的虛擬文本，</p>\r\n', '87500img.jpg', '996710288762_919423534752419_1066153914971804929_n.jpg', 'pages', 0, 0, '2017-05-29 07:16:44', '2017-05-29 00:00:00', '1', 'testing-for-images-update'),
(5, 'New Method', '', '<p>asdfasdfasdfsa</p>\r\n', '<p>asdfasdfafa</p>\r\n', '<p>asdfasdf</p>\r\n', '<p>asdfasdfassfddsa</p>\r\n', '86448481763_4234528360989_393566039_n.jpg', '36975969167_4234503600370_1292568748_n.jpg', 'pages', 0, 0, '2017-05-30 08:38:22', '2017-05-30 00:00:00', '1', 'new-method'),
(8, 'Category Testing', '測試圖像', '', '', '', '', '', '', 'category', 0, 0, '2017-05-31 08:36:57', '0000-00-00 00:00:00', '1', 'category-testing'),
(10, 'Product Testing', '測試圖像', '<p>asdfadf</p>\r\n', '<p>asdfadsfa</p>\r\n', '<p>asdfa</p>\r\n', '<p>adsfas</p>\r\n', '70535969167_4234503600370_1292568748_n.jpg', '74457481763_4234528360989_393566039_n.jpg', 'product', 8, 0, '2017-05-31 12:06:30', '2017-05-31 12:27:12', '1', 'product-testing'),
(12, 'Company News', 'Company News', '', '', '', '', '', NULL, 'newscategory', 0, 0, '2017-06-01 12:29:57', '0000-00-00 00:00:00', '1', 'company-news'),
(14, 'Success Story updatesss', '', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', '75464481763_4234528360989_393566039_n.jpg', '25735969167_4234503600370_1292568748_n.jpg', 'story', 0, 0, '2017-06-02 09:25:46', '2017-06-02 00:00:00', '1', 'success-story-updatesss'),
(15, 'application testsssss', 'application test', '<p>testing for last inserted id</p>\r\n', '<p>testing for last inserted id</p>\r\n', '<p>testing for last inserted id</p>\r\n', '<p>testing for last inserted id</p>\r\n', '', '', 'applications', 0, 0, '2017-06-05 07:18:57', '2017-06-05 09:23:45', '1', 'application-testsssss'),
(16, 'Product for application', 'Product for application', '<p>Product for application</p>\r\n', '<p>Product for application</p>\r\n', '<p>Product for application</p>\r\n', '<p>Product for application</p>\r\n', '', '', 'product', 8, 0, '2017-06-05 07:21:27', '0000-00-00 00:00:00', '1', 'product-for-application'),
(17, 'Story for application', 'Story for application', '<p>Story for application</p>\r\n', '<p>Story for application</p>\r\n', '<p>Story for application</p>\r\n', '<p>Story for application</p>\r\n', '', '', 'story', 0, 0, '2017-06-05 07:21:47', '0000-00-00 00:00:00', '1', 'story-for-application'),
(20, 'Image testing for Application', 'Image testing for Application', '<p>Image testing for Application</p>\r\n', '<p>Image testing for Application</p>\r\n', '<p>Image testing for Application</p>\r\n', '<p>Image testing for Application</p>\r\n', '58890481763_4234528360989_393566039_n.jpg', '67597969167_4234503600370_1292568748_n.jpg', 'applications', 0, 0, '2017-06-05 07:51:07', '0000-00-00 00:00:00', '1', 'image-testing-for-application'),
(22, 'File Upload', 'File Upload', '<p>File Upload</p>\r\n', '<p>File Upload</p>\r\n', '<p>File Upload</p>\r\n', '<p>File Upload</p>\r\n', '', '', 'product', 8, 0, '2017-06-05 13:47:43', '2017-06-12 13:09:39', '1', 'file-upload'),
(23, 'tetttt', '', '', '', '', '', '73404481763_4234528360989_393566039_n.jpg', '68390969167_4234503600370_1292568748_n.jpg', 'product', 8, 0, '2017-06-12 13:10:44', '2017-06-13 06:06:05', '1', 'tetttt');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_postmeta`
--

CREATE TABLE `tbl_postmeta` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_meta_key` varchar(225) NOT NULL,
  `post_meta_value` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_postmeta`
--

INSERT INTO `tbl_postmeta` (`id`, `post_id`, `post_meta_key`, `post_meta_value`) VALUES
(3, 20, 'related_story', 'a:2:{i:0;s:2:"14";i:1;s:2:"17";}'),
(4, 20, 'related_product', 'a:1:{i:0;s:2:"16";}'),
(7, 15, 'related_story', 'a:1:{i:0;s:2:"14";}'),
(8, 15, 'related_product', 'a:2:{i:0;s:2:"10";i:1;s:2:"16";}'),
(9, 22, 'product_file', '11468Crepak_website_design_idea.pptx'),
(10, 22, 'product_file_cn', '11468Crepak_website_design_idea.pptx'),
(11, 23, 'product_file', '89090Crepak_website_design_idea.pptx'),
(12, 23, 'product_file_cn', '96918innerlogo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$VSPeb9I.CeeAiPn24qWDdOcZVTRz8dc9pCT7WeBQzVRxlRNa0w4Ka', '', 'admin@admin.com', '', 'rFUnWXQ21qXQL1DTH58nou950be96e55dcb6f755', 1495709919, 'mlNIgixfjda0xguVOCoChu', 1268889823, 1498104785, 1, 'binaya', 'shresthaa', 'ADMIN', '0');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_images`
--
ALTER TABLE `tbl_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_postmeta`
--
ALTER TABLE `tbl_postmeta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_images`
--
ALTER TABLE `tbl_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `tbl_postmeta`
--
ALTER TABLE `tbl_postmeta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

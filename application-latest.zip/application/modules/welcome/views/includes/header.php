<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $this->config->item('site_title','ion_auth');?></title>
    <link href="<?php echo base_url(); ?>scriptscss/admin/bootstraps/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo base_url(); ?>scriptscss/admin/plugins/jQuery/jQuery-2.1.4.min.js"></script>
</head>
<body>

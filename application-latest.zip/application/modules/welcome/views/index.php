<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<style>
    .section{
        margin: 20% 40% ;
        text-align: center;
        font-size: 40px;
    }
</style>
<body>
<div class="section">
    Login to <a href="<?php echo base_url('digitalauth'); ?>">Digitalauth </a>
</div>


</body>
</html>